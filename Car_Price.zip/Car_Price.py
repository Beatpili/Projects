class Car:

    def Again(self):
        response = str(input("Would you like to try another car?" ))
        if response == 'Yes':
            self.Answer(int(input('What is the price? ')), int(input('How many months? ')), float(input('What is the interest rate? ')))
        elif response == 'No':
            print("Bye")
            


    def Answer(self, Price, Months, Interest):
        self.Price = Price
        LoanPrinciple = self.Price - 5000
        print('Loan Principle: %s' % (LoanPrinciple))
        Test = LoanPrinciple/Months
        Test1 = Interest/100
        InterestRate = Test*Test1
        MonthlyPayment = InterestRate + Test
        print('Your Monthly Payment: %s' % (MonthlyPayment))
        Total = MonthlyPayment * Months
        print('Your Total is: %s' % (Total))
        self.Again()

Car1 = Car()
Car1.Answer(int(input('What is the price? ')), int(input('How many months? ')), float(input('What is the interest rate? ')))  
      
    
        
